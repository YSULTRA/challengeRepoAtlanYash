from django.contrib import admin
from .models import Booking,BookingRequestForDriver

# Admin class for Booking
class BookingInfoAdmin(admin.ModelAdmin):
    list_display = ['driver','user','pickup_location', 'drop_location', 'pickup_lat', 'pickup_lon', 'drop_lat', 'drop_lon', 'booking_datetime', 'price', 'vehicle_type', 'is_driver_assigned', 'booking_status']

# Registering the model with the custom admin
admin.site.register(Booking, BookingInfoAdmin)

admin.site.register(BookingRequestForDriver)
