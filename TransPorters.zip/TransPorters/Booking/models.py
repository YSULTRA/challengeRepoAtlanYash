from django.db import models
from Fleet.models import *
from Users.models import CustomUser
from decimal import Decimal

class Booking(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.SET_NULL, null=True, blank=True) # Reference to allocated driver
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  # Reference to the user making the booking
    pickup_location = models.CharField(max_length=255)
    drop_location = models.CharField(max_length=255)
    pickup_lat = models.DecimalField(max_digits=9, decimal_places=6)
    pickup_lon = models.DecimalField(max_digits=9, decimal_places=6)
    drop_lat = models.DecimalField(max_digits=9, decimal_places=6)
    drop_lon = models.DecimalField(max_digits=9, decimal_places=6)
    booking_datetime = models.DateTimeField()
    price = models.DecimalField(max_digits=10, decimal_places=2)  # Price of the booking
    vehicle_type = models.CharField(max_length=50)  # Type of vehicle requested for the booking
    is_driver_assigned = models.BooleanField(default=False)  # New field to track if a driver is assigned
    booking_status = models.CharField(max_length=50, default="Pending")  # Track booking status like Pending, Completed, etc.

    def __str__(self):
        return f"Booking ID: {self.id} | User: {self.user.name} | Driver: {self.driver.name if self.driver else 'Not Assigned'}"


class BookingRequestForDriver(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.SET_NULL, null=True, blank=True)  # Will be assigned once accepted
    pickup_location = models.CharField(max_length=255)
    drop_location = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(
        max_length=20,
        choices=[('waiting', 'Waiting'), ('accepted', 'Accepted'), ('rejected', 'Rejected')],
        default='waiting'
    )

    def __str__(self):
        return f"Driver:{self.driver.name} | Pickup : {self.pickup_location} | Drop: {self.drop_location} | Price : {self.price}"

