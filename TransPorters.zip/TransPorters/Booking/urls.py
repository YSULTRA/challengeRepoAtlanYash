from django.urls import path
from . import views

urlpatterns = [
    path('book/', views.bookingHandlingView, name='booking-handler'),
    path('bookingConfirmed/<int:booking_id>/', views.bookingConfirmationView, name='booking_confirmation'),
]