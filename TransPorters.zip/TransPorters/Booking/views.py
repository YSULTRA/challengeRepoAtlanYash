from django.shortcuts import render,get_object_or_404,redirect
import requests
from django.db.models import Q
from django.utils import timezone
from decimal import Decimal
from math import radians, sin, cos, sqrt, atan2
from Fleet.models import *
from .models import *
from django.contrib import messages
from channels.layers import *
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync



def bookingConfirmationView(request, booking_id):
    api_key = 'pk.eyJ1IjoieXNzaW5naCIsImEiOiJjbTJieTJua2kwdjl1Mm9zN3Vkdmh3c2gxIn0.dPULQ8MDuSRL7lDOmdqaGg'
    booking = get_object_or_404(Booking, id=booking_id)

    driver = booking.driver
    pickup_coords =  get_coordinates(booking.pickup_location, api_key)
    drop_coords = get_coordinates(booking.drop_location, api_key)
    driver_coords = str(driver.current_lat)+","+ str(driver.current_long)
    print(driver_coords)
    print(drop_coords,type(drop_coords))
    context = {'booking': booking, 'pickup_coords': pickup_coords, 'drop_coords': drop_coords,'pickup_location': booking.pickup_location,'drop_location': booking.drop_location,
    'driver_coords': driver_coords}

    return render(request, 'booking_confirmation.html', context)



def bookingHandlingView(request):
    # Define the Geoapify API keyhttp://127.0.0.1:8000/
    api_key = 'pk.eyJ1IjoieXNzaW5naCIsImEiOiJjbTJieTJua2kwdjl1Mm9zN3Vkdmh3c2gxIn0.dPULQ8MDuSRL7lDOmdqaGg'

    # Initialize variables for pickup and drop coordinates
    pickup_coords = None
    drop_coords = None
    driver_assigned = None

    if request.method == 'POST':
        # Get form data from the POST request
        pickup_location = request.POST.get('pickup-location')
        drop_location = request.POST.get('drop-location')
        vehicle_type = request.POST.get('vehicle-type')
        weight = request.POST.get('weight')
        estimated_price = request.POST.get('estimated_price')


        # Geocode the pickup and drop location names
        pickup_coords = get_coordinates(pickup_location, api_key)
        drop_coords = get_coordinates(drop_location, api_key)
        if pickup_coords and drop_coords:
            # Extract lat/lon from coordinates
            pickup_lat, pickup_lon = map(Decimal, pickup_coords.split(","))
            drop_lat, drop_lon = map(Decimal, drop_coords.split(","))

            # Try to find a driver within a 10km radius with matching vehicle type
            driver_assigned = find_available_driver(pickup_lat, pickup_lon, vehicle_type,pickup_location,drop_location,estimated_price)

            if driver_assigned:
                # Create a new booking object

                print("*************",driver_assigned.name)
                booking = Booking.objects.create(
                    driver=driver_assigned,
                    user=request.user,  # Assuming user is logged in
                    pickup_location=pickup_location,
                    drop_location=drop_location,
                    pickup_lat=pickup_lat,
                    pickup_lon=pickup_lon,
                    drop_lat=drop_lat,
                    drop_lon=drop_lon,
                    booking_datetime=timezone.now(),
                    price=Decimal(estimated_price),
                    vehicle_type=vehicle_type
                )
                print("********")
                # Mark driver as unavailable
                driver_assigned.is_available = False
                driver_assigned.save()
                print("driver found ****",driver_assigned.name)
                return redirect('booking_confirmation', booking_id=booking.id)
            else:
                # If no driver is found, add a message to inform the user
                messages.error(request, "No driver is available currently. Please try again later.")
                return redirect('home')


    # Pass coordinates and form data to the template
    context = {
        'pickup_coords': pickup_coords,
        'drop_coords': drop_coords,
        'pickup_location': pickup_location,
        'drop_location': drop_location,
        'vehicle_type': vehicle_type,
        'weight': weight,
        'estimated_price': estimated_price,
        'driver_assigned': driver_assigned,
    }

    return render(request, 'booking.html', context)

def get_coordinates(location, api_key):
    geocoding_url = f'https://api.mapbox.com/geocoding/v5/mapbox.places/{location}.json?access_token={api_key}'
    response = requests.get(geocoding_url)
    data = response.json()

    if data['features']:
        coords = data['features'][0]['geometry']['coordinates']
        return f"{coords[1]},{coords[0]}"  # Return latitude and longitude
    return None
def find_available_driver(pickup_lat, pickup_lon, vehicle_type,pickup_location,drop_location,estimated_price):
    # Get all available drivers with the matching vehicle type
    available_drivers = Driver.objects.filter(is_available=True, vehicle_id__vehicle_type__vehicle_type=vehicle_type)

    for driver in available_drivers:
        # Calculate the distance between the driver and the pickup location
        driver_distance = calculate_distance(
            pickup_lat, pickup_lon,
            driver.current_lat, driver.current_long
        )

        if driver_distance <= 10:  # 10 km radius
            print("driver send",driver.name)
            booking_req = BookingRequestForDriver.objects.create(
                driver=driver,
                pickup_location=pickup_location,
                drop_location=drop_location,
                price=estimated_price

            )

            print(f"Booking request created for driver: {driver.name}")

            while booking_req.status not in ['accepted', 'rejected']:
                time.sleep(1)  # Sleep for 1 second, simulate waiting for driver's decision
                booking_req.refresh_from_db()
                print("wating for driver respone ")

            print(driver.name)
            return driver  # Return the first matching driver

    return None

def calculate_distance(lat1, lon1, lat2, lon2):
    # Convert latitude and longitude from degrees to radians
    R = 6371  # Radius of the Earth in km
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])

    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))

    return R * c  # Return distance in km


