from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib import messages
from .forms import CustomUserCreationForm
from Fleet.models import VehicleInfo
from .models import CustomUser
import requests
from geopy.exc import GeocoderTimedOut
from decimal import Decimal
from math import radians, sin, cos, sqrt, atan2

def get_coordinates_from_location(location_name):
    try:
        api_key = "29a73ddb43114089b30fe80fb7989517"
        url = f"https://api.geoapify.com/v1/geocode/search?text={location_name}&apiKey={api_key}"
        response = requests.get(url)
        data = response.json()

        if data["features"]:
            # Extract latitude and longitude
            lat = data["features"][0]["geometry"]["coordinates"][1]
            lon = data["features"][0]["geometry"]["coordinates"][0]
            return lat, lon
        else:
            return None, None  # Return None if no coordinates found
    except GeocoderTimedOut:
        print("Geocoding service timed out")
        return None, None

# Haversine Formula to calculate the distance between two coordinates
def haversine(lat1, lon1, lat2, lon2):
    # Radius of the Earth in km
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c
    return distance  # Distance in kilometers

def calculate_estimated_price(pickup_location, drop_location, vehicle_type, weight):
    try:
        # Convert pickup and drop location names to coordinates
        pickup_lat, pickup_lon = get_coordinates_from_location(pickup_location)
        drop_lat, drop_lon = get_coordinates_from_location(drop_location)

        if pickup_lat is None or drop_lat is None:
            print("Error: Invalid location(s). Could not fetch coordinates.")
            return 0

        # Calculate the distance between pickup and drop locations using Haversine formula
        distance = haversine(pickup_lat, pickup_lon, drop_lat, drop_lon)

        # Get the base price of the selected vehicle type
        vehicle = VehicleInfo.objects.get(vehicle_type=vehicle_type)
        base_price = vehicle.base_price

        # Convert base_price to float if it is Decimal (to avoid type mismatch)
        base_price = float(base_price)

        # Price estimation: base_price + distance charge (10 INR/km) + weight charge (10 INR/kg)
        distance_charge = distance * 10  # 10 INR per km
        weight_charge = float(weight) * 10  # 10 INR per kg

        estimated_price = base_price + distance_charge + weight_charge

        return round(estimated_price)

    except Exception as e:
        print(f"Error in calculating estimated price: {e}")
        return 0

def home(request):
    estimated_price = 0
    vehicles = VehicleInfo.objects.all()
    missing_fields = []  # List to store missing fields
    if request.method == 'POST':
        pickup_location = request.POST.get("pickup-location")
        drop_location = request.POST.get("drop-location")
        vehicle_type = request.POST.get("vehicle-type")
        weight = request.POST.get("weight")

        # Check which fields are missing
        if not pickup_location:
            missing_fields.append('pickup location')
        if not drop_location:
            missing_fields.append('drop location')
        if not vehicle_type:
            missing_fields.append('vehicle type')
        if not weight:
            missing_fields.append('weight')

        if missing_fields:
            # If there are missing fields, show an error message
            missing_fields_str = ', '.join(missing_fields)
            messages.error(request, f"Please provide all the details: {missing_fields_str}.")
        else:
            # Calculate the estimated price based on the available data
            estimated_price = calculate_estimated_price(pickup_location, drop_location, vehicle_type, weight)
            # messages.success(request, f"Price: {estimated_price}")

        # Return the home page with the calculated price and the vehicles list
        return render(request, "home.html", {
            "pickup_location": pickup_location,
            "drop_location": drop_location,
            "selected_vehicle_type": vehicle_type,
            "weight": weight,
            "estimated_price": estimated_price,
            "vehicles": vehicles,
            })

    # If the request is GET, just render the home page with no price
    return render(request, 'home.html', {'vehicles': vehicles})




# Register View
def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                username = form.cleaned_data.get('email')
                messages.success(request, f"Account created for {username}!")
                return redirect('login')
            except IntegrityError:
                messages.error(request, "This email is already registered.")
        else:
         
            for field in form.errors:
                print(f"Field: {field}, Errors: {form.errors[field]}")  # Debugging line
    else:
        form = CustomUserCreationForm()
    return render(request, 'Templates/register.html', {'form': form})

# Login View
def user_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        try:
            user = CustomUser.objects.get(email=email)
            if user.check_password(password):
                login(request, user)
                return redirect('home')  # Redirect to the home page after successful login
            else:
                messages.error(request, "Invalid password.")
        except CustomUser.DoesNotExist:
            messages.error(request, "User with this email does not exist.")
    return render(request, 'Templates/login.html')

# Logout View
def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('home')  # Redirect to login page after logout