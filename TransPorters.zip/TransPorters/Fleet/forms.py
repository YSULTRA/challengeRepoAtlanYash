from django import forms
from .models import Driver, VehicleInfo

# Driver Registration Form
class DriverRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    vehicle_type = forms.ModelChoiceField(queryset=VehicleInfo.objects.all(), empty_label="Select Vehicle Type", required=True)

    class Meta:
        model = Driver
        fields = ['name', 'email', 'mobile_number', 'password', 'vehicle_type', 'is_available']

    def clean_vehicle_type(self):
        # If you want to add any custom validation related to vehicle type
        vehicle_type = self.cleaned_data['vehicle_type']
        if not vehicle_type:
            raise forms.ValidationError("Vehicle type is required.")
        return vehicle_type
# Driver Login Form
class DriverLoginForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
