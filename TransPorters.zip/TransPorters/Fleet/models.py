from django.db import models
from django.contrib.auth.hashers import make_password, check_password
import uuid

# VehicleInfo Model (Information about the vehicle type, capacity, price)
class VehicleInfo(models.Model):
    vehicle_type = models.CharField(max_length=50)  # E.g., Car, Van, Truck
    capacity = models.IntegerField()  # Capacity of the vehicle
    base_price = models.DecimalField(max_digits=10, decimal_places=2)  # Base price for the vehicle type
    image_url = models.URLField(max_length=200, blank=True, null=True)  # URL to the vehicle image

    def __str__(self):
        return f"{self.vehicle_type} - {self.capacity} capacity"


# Driver Model (Separate from Users)
class Driver(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    mobile_number = models.CharField(max_length=15)
    password = models.CharField(max_length=255)
    current_lat = models.DecimalField(max_digits=9, decimal_places=6,default=0.0)  # Store latitude
    current_long = models.DecimalField(max_digits=9, decimal_places=6,default=0.0)  # Store longitude
    is_available = models.BooleanField(default=True)

    # Reference to VehicleDriverRelation model to indicate which vehicle the driver is assigned to
    vehicle_id = models.ForeignKey('VehicleDriverRelation', on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.name
    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)


# VehicleDriverRelation Model (Handles the relationship between drivers and vehicles)
class VehicleDriverRelation(models.Model):
    vehicle_id = models.CharField(max_length=100, unique=True, primary_key=True)  # Unique vehicle ID
    vehicle_type = models.ForeignKey(VehicleInfo, on_delete=models.CASCADE)  # ForeignKey to VehicleInfo

    def __str__(self):
        return f"Vehicle ID: {self.vehicle_id} | Type: {self.vehicle_type.vehicle_type}"

    def generate_unique_vehicle_id(self):
        """Generate a unique vehicle ID."""
        return str(uuid.uuid4())  # Create a unique vehicle ID using UUID

    def save(self, *args, **kwargs):

        super().save(*args, **kwargs)