from django.urls import path
from . import views
from .views import UpdateDriverLocationView

urlpatterns = [
    path('driver-home/', views.driver_home, name='driver-home'),
    path('driver-login/', views.driver_login, name='driver-login'),
    path('driver-logout/', views.driver_logout, name='driver-logout'),
    path('register-driver/', views.register_driver, name='register-driver'),
    path('accept_booking/<int:request_id>/', views.accept_booking, name='accept_booking'),
    path('reject_booking/<int:request_id>/', views.reject_booking, name='reject_booking'),
    path('update-driver-location/<int:driver_id>/', UpdateDriverLocationView.as_view(), name='update-driver-location'),

]
