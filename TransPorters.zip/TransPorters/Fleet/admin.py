from django.contrib import admin
from .models import Driver, VehicleInfo, VehicleDriverRelation

# Admin class for VehicleInfo
class VehicleInfoAdmin(admin.ModelAdmin):
    list_display = ('vehicle_type', 'capacity', 'base_price','image_url')

# Admin class for Driver
class DriverAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'mobile_number', 'is_available', 'vehicle_id','current_lat','current_long')

# Admin class for VehicleDriverRelation
class VehicleDriverRelationAdmin(admin.ModelAdmin):
    list_display = ('vehicle_id', 'get_vehicle_type')  # Use a method to get vehicle type

    def get_vehicle_type(self, obj):
        return obj.vehicle_type.vehicle_type  # Access the related vehicle_type field from VehicleInfo
    get_vehicle_type.short_description = 'Vehicle Type'

# Register models with the admin site
admin.site.register(VehicleInfo, VehicleInfoAdmin)
admin.site.register(Driver, DriverAdmin)
admin.site.register(VehicleDriverRelation, VehicleDriverRelationAdmin)
