from rest_framework import serializers
from .models import Driver

class DriverLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Driver
        fields = [ 'id','current_lat', 'current_long']
