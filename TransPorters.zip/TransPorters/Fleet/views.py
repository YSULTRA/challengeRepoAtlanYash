from django.shortcuts import render, redirect,get_object_or_404
from django.contrib import messages
from .models import *
from .forms import DriverRegistrationForm, DriverLoginForm
from django.contrib.sessions.models import Session
from datetime import timedelta
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from django.contrib.auth.hashers import make_password, check_password
from django.db import transaction
from django.contrib.gis.geoip2 import GeoIP2
from django.http import JsonResponse
from Booking.models import *
from .serializers import DriverLocationSerializer
from rest_framework import status
from rest_framework.response import responses
from rest_framework.views import APIView
from django.http import JsonResponse
from rest_framework.response import Response
from rest_framework import status
from django.views import View
from .models import Driver
import json
# Driver Home Page
def driver_home(request):
    # Assuming driver_id is stored in the session
    driver_id = request.session.get('driver_id')


    if driver_id:
        # Fetch the driver object from the database using the driver_id
        driver = get_object_or_404(Driver, id=driver_id)
        pending_requests = BookingRequestForDriver.objects.filter(driver=driver,status='waiting')
        # Pass the driver object to the template
        return render(request, 'Templates/driver_home.html', {'driver': driver, 'pending_requests': pending_requests})
    else:
        # If the driver is not logged in, render a page that invites them to log in or register
        return render(request, 'Templates/driver_without_login.html')

# Register Driver Page
# Register Driver Page
def register_driver(request):
    vehicle_info = VehicleInfo.objects.all()

    if request.method == 'POST':
        form = DriverRegistrationForm(request.POST)
        if form.is_valid():
            # Get the cleaned data from the form
            vehicle_type = form.cleaned_data['vehicle_type']
            is_available = form.cleaned_data['is_available']
            current_lat = request.POST.get('current_lat')  # Get lat from hidden field
            current_long = request.POST.get('current_long')  # Get long from hidden field

            try:
                # Step 1: Create VehicleDriverRelation object first
                with transaction.atomic():  # Start a transaction
                    vehicle_driver_relation = VehicleDriverRelation(
                        vehicle_type=vehicle_type,  # Link to the selected vehicle type
                        vehicle_id=VehicleDriverRelation.generate_unique_vehicle_id(vehicle_type)  # Set unique vehicle ID
                    )
                    vehicle_driver_relation.save()  # Save the relation first to generate vehicle_id

                    # Step 2: Create Driver object and link it to the VehicleDriverRelation
                    driver = form.save(commit=False)
                    driver.vehicle_id = vehicle_driver_relation  # Link the driver to the vehicle relation
                    driver.current_lat = current_lat  # Set the driver's latitude
                    driver.current_long = current_long  # Set the driver's longitude
                    driver.set_password(form.cleaned_data['password'])  # Hash the password before saving
                    print("driver made 1")
                    driver.save()  # Save the driver after linking to vehicle_driver_relation
                    print("driver made 2")
                # If everything goes well, commit the transaction
                messages.success(request, "Driver registered successfully!")
                return redirect('driver-login')

            except Exception as e:
                # If an error occurs, the transaction is rolled back, and both objects are not saved
                messages.error(request, "Failed to register the driver. Please try again.")
                print(f"Error: {e}")


    else:
        form = DriverRegistrationForm()

    return render(request, 'Templates/register_driver.html', {'form': form, 'vehicle_info': vehicle_info})


# Driver Login (Manual Authentication)
def driver_login(request):
    if request.method == 'POST':
        form = DriverLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')

            try:
                driver = Driver.objects.get(email=email)
                if driver.check_password(password):
                    current_lat = request.POST.get('current_lat')  # Get lat from hidden field or request
                    current_long = request.POST.get('current_long')  # Get long from hidden field or request

                    # If lat/long is provided, update the driver
                    if current_lat and current_long:
                        print(driver.current_lat,driver.current_long)
                        current_lat = float(current_lat)
                        current_long = float(current_long)
                        driver.current_lat = current_lat
                        driver.current_long = current_long
                        print(current_lat,current_long)
                        print(driver.current_lat,driver.current_long)
                        driver.save()
                    request.session['driver_id'] = driver.id
                    request.session['driver_email'] = driver.email
                    request.session['driver_name'] = driver.name
                    messages.success(request, 'Login successful!')
                    request.session.set_expiry(timedelta(hours=2))  # Sessions expire in 2 hours

                    return redirect('driver-home')
                else:
                    messages.error(request, 'Invalid password.')
            except Driver.DoesNotExist:
                messages.error(request, 'Driver not found.')
    else:
        form = DriverLoginForm()

    return render(request, 'Templates/login_driver.html', {'form': form})

# Driver Logout
def driver_logout(request):
    # Remove driver session data
    if 'driver_id' in request.session:
        del request.session['driver_id']
        del request.session['driver_email']
        messages.success(request, 'You have been logged out.')
    return redirect('driver-login')


def accept_booking(request, request_id):
    booking_request = get_object_or_404(BookingRequestForDriver, id=request_id)
    booking_request.status = 'accepted'
    booking_request.save()
    return redirect('driver-home')

def reject_booking(request, request_id):
    booking_request = get_object_or_404(BookingRequestForDriver, id=request_id)
    booking_request.status = 'rejected'
    booking_request.save()
    return redirect('driver-home')



class UpdateDriverLocationView(View):
    def post(self, request, driver_id):
        try:
            # Parse JSON data from the body
            data = json.loads(request.body)

            latitude = data.get('current_lat')
            longitude = data.get('current_long')
            print(latitude,longitude)

            # Get driver using the driver_id
            driver = Driver.objects.get(id=driver_id)

            # Update the driver's location
            driver.current_lat = latitude
            driver.current_long = longitude
            print("driver location updated")
            driver.save()

            return Response({'status': 'success', 'message': 'Driver location updated.'}, status=status.HTTP_200_OK)

        except Driver.DoesNotExist:
            return Response({"error": "Driver not found"}, status=status.HTTP_404_NOT_FOUND)

        except json.JSONDecodeError:
            return Response({"error": "Invalid JSON format"}, status=status.HTTP_400_BAD_REQUEST)