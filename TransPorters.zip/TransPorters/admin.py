from django.contrib import admin
from .models import CustomUser

class UserAdmin(admin.ModelAdmin):
    # List the fields you want to display in the list view
    list_display = ('name', 'email', 'mobile_number')

    # Enable search functionality
    search_fields = ('name', 'email')

    # Allow editing certain fields directly in the list view (but avoid username or other critical fields)
    list_editable = ('mobile_number',)

    # Ensure only users with necessary permissions can edit sensitive data
    list_filter = ('is_active', 'is_staff', 'is_superuser')  # Optional: Add filters for user status

    # Ordering of the list view
    ordering = ('name',)  # Optional: Set a default ordering

    # Ensure that the fields are properly displayed in the form
    fieldsets = (
        (None, {'fields': ('name', 'email', 'mobile_number', 'password')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser')}),
        ('Important dates', {'fields': ('last_login',)}),
    )

# Register the User model with the custom admin
admin.site.register(CustomUser, UserAdmin)
